import React from 'react'

type Props = {}

export default function About({}: Props) {
  return (
    <div>About</div>
  )
}